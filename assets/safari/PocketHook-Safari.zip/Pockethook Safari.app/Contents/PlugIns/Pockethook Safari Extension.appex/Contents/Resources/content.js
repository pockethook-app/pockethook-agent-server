function requireElement(selector) {
  const element = document.querySelector(selector);
  if (!element) throw new Error(`No element matches ${selector}`);
  return element;
}

function snapshot() {
  const interactive = [...document.querySelectorAll("a, button, input, textarea, select, [role='button']")]
    .slice(0, 5)
    .map((element, index) => ({
      index,
      tag: element.tagName.toLowerCase(),
      text: (element.innerText || element.getAttribute("aria-label") || element.getAttribute("placeholder") || "").trim().slice(0, 60),
    }));
  return {
    title: document.title,
    url: location.href,
    text: (document.body?.innerText || "").trim().slice(0, 160),
    interactive,
  };
}

browser.runtime.onMessage.addListener(async (message) => {
  if (message.type !== "page_action") return;
  const action = message.action || {};
  try {
    let result;
    switch (action.kind) {
      case "snapshot":
        result = snapshot();
        break;
      case "click":
        requireElement(action.selector).click();
        result = { ok: true };
        break;
      case "fill": {
        const element = requireElement(action.selector);
        if (!(element instanceof HTMLInputElement || element instanceof HTMLTextAreaElement || element.isContentEditable)) {
          throw new Error("Target is not editable");
        }
        element.focus();
        if (element.isContentEditable) element.textContent = action.text || "";
        else element.value = action.text || "";
        element.dispatchEvent(new InputEvent("input", { bubbles: true, inputType: "insertText", data: action.text || "" }));
        element.dispatchEvent(new Event("change", { bubbles: true }));
        result = { ok: true };
        break;
      }
      case "read_text":
        result = { text: requireElement(action.selector).innerText };
        break;
      case "scroll":
        window.scrollBy({ top: Number(action.y) || 0, left: Number(action.x) || 0, behavior: "instant" });
        result = { ok: true, x: window.scrollX, y: window.scrollY };
        break;
      default:
        throw new Error(`Unsupported page action: ${action.kind}`);
    }
    if (message.requestId) await browser.runtime.sendMessage({ type: "page_action_result", requestId: message.requestId, ok: true, result });
    return result;
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : String(error);
    if (message.requestId) await browser.runtime.sendMessage({ type: "page_action_result", requestId: message.requestId, ok: false, error: errorMessage });
    throw error;
  }
});

function keepBridgeAvailable() {
  browser.runtime.sendMessage({ type: "poll_native_bridge" }).catch(() => {});
}

keepBridgeAvailable();
setInterval(keepBridgeAvailable, 1_000);
