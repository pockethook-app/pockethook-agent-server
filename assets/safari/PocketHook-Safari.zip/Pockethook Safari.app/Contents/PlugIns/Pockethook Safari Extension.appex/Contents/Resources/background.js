const DEFAULT_ENDPOINT = "ws://127.0.0.1:4000/safari-extension";
let socket;
let reconnectTimer;

// Connection health, reported to the popup on request.
const bridge = { lastPollOkAt: 0, lastError: "", unpairedByServer: false };

async function settings() {
  const stored = await browser.storage.local.get(["endpoint", "installationId", "credential"]);
  if (!stored.installationId) {
    stored.installationId = crypto.randomUUID();
    await browser.storage.local.set({ installationId: stored.installationId });
  }
  return { endpoint: stored.endpoint || DEFAULT_ENDPOINT, ...stored };
}

async function connect() {
  const { endpoint, installationId, credential } = await settings();
  if (!credential || socket?.readyState === WebSocket.CONNECTING || socket?.readyState === WebSocket.OPEN) return;
  try {
    socket = new WebSocket(endpoint);
    socket.onopen = () => send({ type: "hello", installationId, credential });
    socket.onmessage = (event) => {
      bridge.lastPollOkAt = Date.now();
      handleServerMessage(event.data);
    };
    socket.onclose = () => scheduleReconnect();
    socket.onerror = () => socket?.close();
  } catch {
    scheduleReconnect();
  }
}

function scheduleReconnect() {
  clearTimeout(reconnectTimer);
  reconnectTimer = setTimeout(connect, 3_000);
}

function send(message) {
  if (socket?.readyState === WebSocket.OPEN) socket.send(JSON.stringify(message));
}

async function executeCommand(command, payload = {}) {
  switch (command) {
    case "open_tab": {
      const tab = await browser.tabs.create({ url: payload.url, active: payload.active !== false });
      return { id: tab.id, url: tab.url, title: tab.title };
    }
    case "navigate_tab": {
      const tab = await browser.tabs.update(payload.tabId, { url: payload.url, active: payload.active !== false });
      return { id: tab.id, url: tab.url, title: tab.title };
    }
    case "get_active_tab": {
      const [tab] = await browser.tabs.query({ active: true, currentWindow: true });
      return tab ? { id: tab.id, url: tab.url, title: tab.title } : null;
    }
    case "capture_visible_tab":
      return { dataUrl: await browser.tabs.captureVisibleTab(undefined, { format: "png" }) };
    case "close_tab": {
      if (!payload.tabId) throw new Error("close_tab requires tabId");
      await browser.tabs.remove(payload.tabId);
      return { ok: true, closed: payload.tabId };
    }
    case "get_page_snapshot": {
      if (!payload.tabId) throw new Error("get_page_snapshot requires tabId");
      return executePageAction(payload.tabId, { kind: "snapshot" });
    }
    case "page_action": {
      if (!payload.tabId) throw new Error("page_action requires tabId");
      return executePageAction(payload.tabId, payload.action);
    }
    default:
      throw new Error(`Unsupported command: ${command}`);
  }
}

// Errors thrown deliberately by the injected page script. Anything else that
// rejects executeScript (or a hang) usually means the click navigated away and
// destroyed the page context before it could report back.
const PAGE_ERROR_PREFIXES = ["Click blocked", "Fill blocked", "Locator is stale", "No selector", "Unsupported page action"];

async function executePageAction(tabId, action) {
  const tabBefore = await browser.tabs.get(tabId).catch(() => null);
  let results;
  try {
    results = await Promise.race([
      runPageScript(tabId, action),
      new Promise((_, reject) => setTimeout(() => reject(new Error("page_script_timeout")), 8_000)),
    ]);
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    const intentional = PAGE_ERROR_PREFIXES.some((prefix) => message.startsWith(prefix));
    if (!intentional && (action.kind === "click" || action.kind === "fill")) {
      const tab = await browser.tabs.get(tabId).catch(() => null);
      if (!tab) return { ok: true, completed: "unverified", note: "The tab is gone after the action; it may have closed or been replaced." };
      const navigated = Boolean(tabBefore?.url) && tab.url !== tabBefore.url;
      return {
        ok: true,
        completed: "unverified",
        navigated,
        url_before: tabBefore?.url,
        url_after: tab.url,
        title: tab.title,
        note: navigated
          ? "The action triggered a navigation, so the page could not report before/after state. Inspect the new page to verify the outcome."
          : "The page did not report back in time. Inspect the page to verify whether the action took effect.",
      };
    }
    if (message === "page_script_timeout") throw new Error("The page did not respond within 8 seconds");
    throw error;
  }
  const frameResults = results.map((entry) => ({ frame_id: entry.frameId, ...(entry.result || {}) }));
  return action.kind === "snapshot" ? { frames: frameResults } : frameResults[0] ?? null;
}

function runPageScript(tabId, action) {
  return browser.scripting.executeScript({
    target: action.locator?.frame_id === undefined ? { tabId, allFrames: action.kind === "snapshot" } : { tabId, frameIds: [action.locator.frame_id] },
    func: async (pageAction) => {
      const interactiveSelector = "a, button, input, textarea, select, summary, [role='button'], [role='link'], [role='checkbox'], [role='menuitem'], [role='tab'], [role='textbox'], [contenteditable='true'], [contenteditable='']";
      const cssEscape = (value) => globalThis.CSS?.escape ? CSS.escape(value) : String(value).replace(/[^a-zA-Z0-9_-]/g, "\\\\$&");
      const visible = (element) => {
        const style = getComputedStyle(element);
        const rect = element.getBoundingClientRect();
        return style.display !== "none" && style.visibility !== "hidden" && Number(style.opacity) !== 0 && rect.width > 0 && rect.height > 0;
      };
      const label = (element) => (element.innerText || element.getAttribute("aria-label") || element.getAttribute("placeholder") || element.value || "").trim();
      const selectorFor = (element, root = document) => {
        if (element.id && root.querySelectorAll(`#${cssEscape(element.id)}`).length === 1) return `#${cssEscape(element.id)}`;
        for (const attribute of ["data-testid", "data-test", "data-id", "name", "aria-label"]) {
          const value = element.getAttribute(attribute);
          const selector = `${element.tagName.toLowerCase()}[${attribute}="${cssEscape(value || "")}"]`;
          if (value && root.querySelectorAll(selector).length === 1) return selector;
        }
        const parts = [];
        let current = element;
        while (current && current !== root) {
          const tag = current.tagName.toLowerCase();
          const siblings = [...current.parentElement.children].filter((sibling) => sibling.tagName === current.tagName);
          parts.unshift(siblings.length === 1 ? tag : `${tag}:nth-of-type(${siblings.indexOf(current) + 1})`);
          const candidate = parts.join(" > ");
          if (root.querySelectorAll(candidate).length === 1) return candidate;
          current = current.parentElement;
        }
        return parts.join(" > ");
      };
      const locatorFor = (element) => {
        const shadowHosts = [];
        let current = element;
        let root = current.getRootNode();
        const selector = selectorFor(current, root);
        while (root instanceof ShadowRoot) {
          const host = root.host;
          const hostRoot = host.getRootNode();
          shadowHosts.unshift(selectorFor(host, hostRoot));
          current = host;
          root = hostRoot;
        }
        return { selector, shadow_hosts: shadowHosts, frame_url: location.href };
      };
      const resolveLocator = (locator, fallbackSelector) => {
        let root = document;
        for (const hostSelector of locator?.shadow_hosts || []) {
          const host = root.querySelector(hostSelector);
          if (!host?.shadowRoot) throw new Error("Locator is stale: shadow host is missing or closed");
          root = host.shadowRoot;
        }
        const selector = locator?.selector || fallbackSelector;
        if (!selector) throw new Error("No selector or locator was supplied");
        const element = root.querySelector(selector);
        if (!element) throw new Error("Locator is stale: the target no longer exists");
        return element;
      };
      const controls = (root = document, found = []) => {
        for (const element of root.querySelectorAll(interactiveSelector)) if (visible(element)) found.push(element);
        for (const element of root.querySelectorAll("*")) if (element.shadowRoot) controls(element.shadowRoot, found);
        return found;
      };
      const stateFor = (element) => ({
        text: label(element).slice(0, 200), value: "value" in element ? String(element.value ?? "") : undefined,
        disabled: Boolean(element.disabled || element.getAttribute("aria-disabled") === "true"),
        pressed: element.getAttribute("aria-pressed"), visible: visible(element),
      });
      const waitForRender = () => new Promise((resolve) => requestAnimationFrame(() => requestAnimationFrame(resolve)));
      // Mimic a real click as closely as an untrusted event allows: aim at the
      // innermost element under the cursor (real clicks land on the icon or
      // label inside a button and bubble up, and handlers may hang off that
      // child or read event.target), use real coordinates, detail 1, and the
      // correct buttons bitmask per phase. A bare element.click() would report
      // detail 0 at 0,0 on the button itself, which some handlers discard.
      const fireClick = (element) => {
        const rect = element.getBoundingClientRect();
        const cx = rect.left + rect.width / 2;
        const cy = rect.top + rect.height / 2;
        let target = document.elementFromPoint(cx, cy);
        while (target?.shadowRoot) {
          const inner = target.shadowRoot.elementFromPoint(cx, cy);
          if (!inner || inner === target) break;
          target = inner;
        }
        if (!target || !(element === target || element.contains(target))) target = element;
        const at = (extra) => ({ bubbles: true, cancelable: true, composed: true, view: window, button: 0, detail: 1, clientX: cx, clientY: cy, ...extra });
        const pointer = { pointerId: 1, pointerType: "mouse", isPrimary: true };
        target.dispatchEvent(new PointerEvent("pointerover", at({ ...pointer, buttons: 0 })));
        target.dispatchEvent(new MouseEvent("mouseover", at({ buttons: 0 })));
        target.dispatchEvent(new MouseEvent("mousemove", at({ buttons: 0 })));
        target.dispatchEvent(new PointerEvent("pointerdown", at({ ...pointer, buttons: 1 })));
        target.dispatchEvent(new MouseEvent("mousedown", at({ buttons: 1 })));
        if (element.focus) element.focus({ preventScroll: true });
        target.dispatchEvent(new PointerEvent("pointerup", at({ ...pointer, buttons: 0 })));
        target.dispatchEvent(new MouseEvent("mouseup", at({ buttons: 0 })));
        target.dispatchEvent(new MouseEvent("click", at({ buttons: 0 })));
      };
      // React tracks input values through the prototype setter; writing
      // element.value directly leaves its internal state out of sync.
      const setNativeValue = (element, value) => {
        const proto = element instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype
          : element instanceof HTMLInputElement ? HTMLInputElement.prototype
          : null;
        const setter = proto && Object.getOwnPropertyDescriptor(proto, "value")?.set;
        if (setter) setter.call(element, value);
        else element.value = value;
      };
      // Attributes that identify a control semantically; shown to the model so
      // it can tell a page's primary action apart from lookalikes.
      const attributesFor = (element) => {
        const picked = {};
        for (const attribute of ["data-test", "data-testid", "id", "name", "aria-label", "title", "type", "href"]) {
          const value = element.getAttribute(attribute);
          if (value) picked[attribute] = String(value).slice(0, 120);
        }
        return picked;
      };
      const strongLocator = (element) =>
        ["data-test", "data-testid", "id", "name", "aria-label"].some((attribute) => element.getAttribute(attribute));
      // Surrounding text that distinguishes the control (e.g. the comment it
      // belongs to). Walk up until an ancestor adds text beyond the control's
      // own label; the control itself never counts as its own context.
      const contextFor = (element) => {
        const own = label(element);
        let container = element.parentElement;
        while (container && container !== document.body) {
          const text = (container.innerText || "").trim().replace(/\s+/g, " ");
          if (text.length >= own.length + 15) return text.slice(0, 160);
          container = container.parentElement;
        }
        return "";
      };
      if (pageAction.kind === "snapshot") {
        const CAP = 120;
        const all = controls();
        let kept = all;
        if (all.length > CAP) {
          // Controls with a semantic identifier (data-test, id, aria-label…)
          // are usually the page's real actions — never let long navs and
          // comment lists push them past the cap.
          const strong = all.filter(strongLocator);
          const seen = new Set(strong.slice(0, CAP));
          kept = [...seen];
          for (const element of all) {
            if (kept.length >= CAP) break;
            if (!seen.has(element)) kept.push(element);
          }
        }
        const interactive = kept.map((element, index) => ({ index, tag: element.tagName.toLowerCase(), locator: locatorFor(element), attributes: attributesFor(element), ...stateFor(element) }));
        return { title: document.title, url: location.href, text: (document.body?.innerText || "").trim().slice(0, 4_000), interactive, total_controls: all.length, truncated: all.length > CAP };
      }
      if (pageAction.kind === "click") {
        const element = resolveLocator(pageAction.locator, pageAction.selector);
        const before = stateFor(element);
        const urlBefore = location.href;
        if (!before.visible) throw new Error("Click blocked: target is not visible");
        if (before.disabled) throw new Error("Click blocked: target is disabled");
        element.scrollIntoView({ block: "center", inline: "center" });
        const rect = element.getBoundingClientRect();
        const top = document.elementFromPoint(Math.min(Math.max(rect.left + rect.width / 2, 0), innerWidth - 1), Math.min(Math.max(rect.top + rect.height / 2, 0), innerHeight - 1));
        if (top && top !== element && !element.contains(top) && !top.contains(element)) throw new Error(`Click blocked by ${top.tagName.toLowerCase()}${top.id ? `#${top.id}` : ""}`);
        fireClick(element);
        await waitForRender();
        // Give the site time to react (network round-trip, re-render). The
        // original node may be replaced by a re-render, so re-resolve the
        // locator on every check instead of trusting the stale reference.
        const currentTarget = () => {
          try { return resolveLocator(pageAction.locator, pageAction.selector); }
          catch { return null; }
        };
        let after = stateFor(currentTarget() ?? element);
        const settleDeadline = Date.now() + 1_500;
        while (JSON.stringify(after) === JSON.stringify(before) && location.href === urlBefore && Date.now() < settleDeadline) {
          await new Promise((resolve) => setTimeout(resolve, 150));
          const fresh = currentTarget();
          if (!fresh) break;
          after = stateFor(fresh);
        }
        const stateChanged = JSON.stringify(after) !== JSON.stringify(before) || location.href !== urlBefore;
        return {
          ok: true,
          target: { locator: pageAction.locator ?? { selector: pageAction.selector }, ...after },
          before,
          after,
          state_changed: stateChanged,
          ...(stateChanged ? {} : { note: "The control did not change within 1.5s of the click. The site may be ignoring synthetic (untrusted) clicks for this control; if a retry with the exact same locator also reports state_changed: false, stop and ask the user to perform this click manually." }),
          url_before: urlBefore,
          url_after: location.href,
          likely_requires_login: /log in|sign in/i.test(document.body?.innerText || ""),
        };
      }
      if (pageAction.kind === "fill") {
        const element = resolveLocator(pageAction.locator, pageAction.selector);
        if (!(element instanceof HTMLInputElement || element instanceof HTMLTextAreaElement || element.isContentEditable)) throw new Error("Fill blocked: target is not editable");
        const before = stateFor(element);
        element.focus();
        if (element.isContentEditable) element.textContent = pageAction.text || "";
        else setNativeValue(element, pageAction.text || "");
        element.dispatchEvent(new InputEvent("input", { bubbles: true, inputType: "insertText", data: pageAction.text || "" }));
        element.dispatchEvent(new Event("change", { bubbles: true }));
        await waitForRender();
        return { ok: true, target: { locator: locatorFor(element), ...stateFor(element) }, before, after: stateFor(element) };
      }
      if (pageAction.kind === "read_text") return { text: label(resolveLocator(pageAction.locator, pageAction.selector)) };
      if (pageAction.kind === "find_text") {
        const query = String(pageAction.text || "").trim().toLowerCase();
        const candidates = controls().filter((element) => !pageAction.selector || element.matches(pageAction.selector));
        const matching = candidates
          .map((element) => ({ element, text: label(element).toLowerCase() }))
          .filter(({ element, text }) => {
            if (text.includes(query)) return true;
            // Also match identifying attributes, so a query like "vote"
            // finds [data-test="vote-button"] even when its label differs.
            return Object.values(attributesFor(element)).some((value) => value.toLowerCase().includes(query));
          });
        // Exact label matches first; among equals, controls with a semantic
        // identifier outrank anonymous nth-of-type chains (a page's primary
        // action almost always carries one).
        const rank = ({ element, text }) => (text === query ? 2 : 0) + (strongLocator(element) ? 1 : 0);
        matching.sort((a, b) => rank(b) - rank(a));
        const matches = matching.slice(0, 8).map(({ element, text }) => ({
          exact: text === query,
          tag: element.tagName.toLowerCase(),
          locator: locatorFor(element),
          attributes: attributesFor(element),
          context: contextFor(element),
          ...stateFor(element),
        }));
        return { found: matches.length > 0, total_matches: matching.length, matches };
      }
      if (pageAction.kind === "scroll") { window.scrollBy({ top: Number(pageAction.y) || 0, left: Number(pageAction.x) || 0, behavior: "instant" }); return { ok: true, x: window.scrollX, y: window.scrollY }; }
      throw new Error(`Unsupported page action: ${pageAction.kind}`);
    },
    args: [action],
  });
}

async function commandResult(requestId, operation) {
  let outcome;
  try {
    outcome = { ok: true, result: await operation() };
  } catch (error) {
    outcome = { ok: false, error: error instanceof Error ? error.message : String(error) };
  }
  // Prefer the socket that delivered the command; if it died mid-command,
  // fall back to the HTTP result endpoint so the answer is never lost.
  if (socket?.readyState === WebSocket.OPEN) {
    send({ type: "result", requestId, ...outcome });
    return;
  }
  const { installationId, credential } = await settings();
  try {
    await submitResult({ installationId, credential, requestId, ...outcome });
  } catch { /* The server will time the command out. */ }
}

async function handleCommand({ requestId, command, payload = {} }) {
  await commandResult(requestId, () => executeCommand(command, payload));
}

function handleServerMessage(raw) {
  let message;
  try { message = JSON.parse(raw); } catch { return; }
  if (message.type === "command") handleCommand(message);
  if (message.type === "wake") pollNativeBridge();
}

browser.runtime.onMessage.addListener(async (message) => {
  if (message.type === "page_action_result") {
    const { installationId, credential } = await settings();
    const payload = { installationId, credential, requestId: message.requestId, ok: message.ok, result: message.result, error: message.error };
    try {
      await submitResult(payload);
    } catch {
      await browser.runtime.sendNativeMessage({
        type: "result",
        installationId,
        credential,
        requestId: message.requestId,
        ok: message.ok,
        resultJson: JSON.stringify(message.result),
        error: message.error,
      });
    }
    return { ok: true };
  }
  if (message.type === "poll_native_bridge") {
    await pollNativeBridge();
    return { ok: true };
  }
  if (message.type === "status") {
    const { endpoint, installationId, credential } = await settings();
    return {
      paired: Boolean(credential),
      installationId,
      endpoint,
      connected: Boolean(credential) && Date.now() - bridge.lastPollOkAt < 3_000,
      lastContactAt: bridge.lastPollOkAt || null,
      unpairedByServer: bridge.unpairedByServer,
      error: bridge.lastError || undefined,
    };
  }
  if (message.type === "unpair") {
    await browser.storage.local.remove("credential");
    bridge.lastPollOkAt = 0;
    bridge.lastError = "";
    bridge.unpairedByServer = false;
    return { ok: true };
  }
  if (message.type !== "pair") return;
  const { installationId } = await settings();
  try {
    const reply = await browser.runtime.sendNativeMessage({ type: "pair", installationId, code: message.code });
    if (!reply?.credential) return { error: reply?.error || "Pairing was rejected." };
    await browser.storage.local.set({ credential: reply.credential, endpoint: DEFAULT_ENDPOINT });
    bridge.lastPollOkAt = Date.now();
    bridge.lastError = "";
    bridge.unpairedByServer = false;
    return { message: "Paired with Agent Server." };
  } catch (error) {
    return { error: error instanceof Error ? error.message : "Could not reach the PocketHook app." };
  }
});

let pollInFlight = false;

async function pollNativeBridge() {
  if (pollInFlight) return;
  pollInFlight = true;
  try {
    await pollNativeBridgeOnce();
  } finally {
    pollInFlight = false;
  }
}

async function pollNativeBridgeOnce() {
  const { installationId, credential } = await settings();
  if (!credential) return;
  if (!socket || socket.readyState === WebSocket.CLOSING || socket.readyState === WebSocket.CLOSED) connect();
  // Drain the whole queue in one cycle: the server hands over one command per
  // poll, and waiting 750ms between consecutive commands adds up fast in
  // multi-step flows (open, inspect, click, close…).
  for (let drained = 0; drained < 10; drained++) {
    let reply;
    try {
      reply = await browser.runtime.sendNativeMessage({ type: "poll", installationId, credential });
    } catch {
      bridge.lastError = "Could not reach the PocketHook app or the local Agent Server.";
      return;
    }
    if (reply?.error) {
      bridge.lastError = reply.error;
      bridge.unpairedByServer = /not paired/i.test(reply.error);
      return;
    }
    bridge.lastPollOkAt = Date.now();
    bridge.lastError = "";
    bridge.unpairedByServer = false;
    if (!reply?.command) return;
    const { requestId, command, payload } = reply.command;
    try {
      const result = await executeCommand(command, { ...payload, requestId });
      await submitResult({ installationId, credential, requestId, ok: true, result });
    } catch (error) {
      try {
        await submitResult({ installationId, credential, requestId, ok: false, error: error instanceof Error ? error.message : String(error) });
      } catch {
        bridge.lastError = "Could not deliver a command result to Agent Server.";
        return;
      }
    }
  }
}

async function submitResult(message) {
  const response = await fetch("http://127.0.0.1:4000/safari-extension/native/result", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(message),
  });
  if (!response.ok) throw new Error("Could not deliver the command result to Agent Server");
}

// Safari suspends this page when nothing keeps it busy; every hook below is a
// chance to wake up, drain queued commands, and re-open the socket. Without
// them, closing the last real web page tab (content scripts don't run on the
// start page) silently stopped all polling until the user clicked the toolbar
// icon, and every command timed out meanwhile.
setInterval(pollNativeBridge, 750);
browser.alarms.create("pockethook-wake", { periodInMinutes: 1 });
browser.alarms.onAlarm.addListener(() => pollNativeBridge());
browser.tabs.onActivated.addListener(() => pollNativeBridge());
browser.tabs.onUpdated.addListener(() => pollNativeBridge());
browser.tabs.onRemoved.addListener(() => pollNativeBridge());
browser.windows.onFocusChanged.addListener(() => pollNativeBridge());
connect();
pollNativeBridge();
