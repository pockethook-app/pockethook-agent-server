const endpoint = document.querySelector("#endpoint");
const code = document.querySelector("#code");
const status = document.querySelector("#status");
const dot = document.querySelector("#dot");
const connectionText = document.querySelector("#connection-text");
const pairForm = document.querySelector("#pair-form");
const actions = document.querySelector("#actions");

let showFormWhilePaired = false;

browser.storage.local.get("endpoint").then((stored) => { if (stored.endpoint) endpoint.value = stored.endpoint; });

function render(state) {
  if (!state) {
    dot.className = "dot off";
    connectionText.textContent = "Extension is starting…";
    return;
  }
  if (!state.paired) {
    dot.className = "dot off";
    connectionText.textContent = "Not paired with Agent Server.";
  } else if (state.connected) {
    dot.className = "dot on";
    connectionText.textContent = "Connected to Agent Server.";
  } else if (state.unpairedByServer) {
    dot.className = "dot warn";
    connectionText.textContent = "Agent Server no longer recognizes this pairing. Pair again.";
  } else {
    dot.className = "dot warn";
    connectionText.textContent = state.error || "Paired, but Agent Server is not responding.";
  }
  pairForm.hidden = state.paired && !state.unpairedByServer && !showFormWhilePaired;
  actions.hidden = !state.paired;
}

async function refresh() {
  try {
    render(await browser.runtime.sendMessage({ type: "status" }));
  } catch {
    render(undefined);
  }
}

document.querySelector("#pair").addEventListener("click", async () => {
  if (!code.value.trim()) { status.textContent = "Enter the pairing code from Agent Server."; return; }
  try {
    const url = new URL(endpoint.value);
    if (!["127.0.0.1", "localhost", "::1"].includes(url.hostname)) throw new Error("Use a local server address.");
    const result = await browser.runtime.sendMessage({ type: "pair", endpoint: endpoint.value, code: code.value.trim() });
    status.textContent = result?.error || result?.message || "Pairing request sent.";
    if (!result?.error) {
      code.value = "";
      showFormWhilePaired = false;
      await refresh();
    }
  } catch (error) {
    status.textContent = error instanceof Error ? error.message : "Unable to pair.";
  }
});

document.querySelector("#repair").addEventListener("click", () => {
  showFormWhilePaired = true;
  pairForm.hidden = false;
  code.focus();
});

document.querySelector("#unpair").addEventListener("click", async () => {
  await browser.runtime.sendMessage({ type: "unpair" });
  status.textContent = "Pairing removed.";
  showFormWhilePaired = false;
  await refresh();
});

refresh();
setInterval(refresh, 1_000);
